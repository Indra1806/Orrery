import { createFileRoute } from "@tanstack/react-router";
import { Orrery } from "@/game/Orrery";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="h-dvh w-full overflow-hidden bg-bg text-fg">
      <Orrery />
    </main>
  );
}
