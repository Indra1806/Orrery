export const R_MIN = 88;
export const R_MAX = 252;
export const RADIAL_SPEED = 380;
export const FORGIVE = 8;
export const HOLD_R = R_MIN + 12;
export const RELEASE_R = R_MAX - 12;

export type Phase = "title" | "playing" | "paused" | "dead";
export type Cue = "gate" | "near" | "collect" | "die";
export type Tone = "bone" | "rust";

export type Gate = {
  id: number;
  angle: number;
  gapMin: number;
  gapMax: number;
  resolved: boolean;
  near: boolean;
};

export type Mote = {
  id: number;
  angle: number;
  radius: number;
  taken: boolean;
  missed: boolean;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  tone: Tone;
};

export type Floater = {
  x: number;
  y: number;
  text: string;
  life: number;
  max: number;
};

export type TrailPoint = { x: number; y: number };

export type Sim = {
  phase: Phase;
  time: number;
  elapsed: number;
  score: number;
  best: number;
  prevBest: number;
  combo: number;
  bestCombo: number;
  holding: boolean;
  omega: number;
  player: { angle: number; radius: number; radialVel: number };
  gates: Gate[];
  motes: Mote[];
  particles: Particle[];
  floaters: Floater[];
  trail: TrailPoint[];
  trauma: number;
  flash: number;
  playerFlash: number;
  hitstop: number;
  spawned: number;
  passed: number;
  nextAngle: number;
  nextId: number;
  rng: number;
  deathAge: number;
  crashed: boolean;
  nearMisses: number;
  motesTaken: number;
  newBest: boolean;
  bestDirty: boolean;
  shakeOn: boolean;
  reduced: boolean;
  cue: Cue | null;
};

const CUE_RANK: Record<Cue, number> = { gate: 1, near: 2, collect: 3, die: 4 };

export function createSim(): Sim {
  return {
    phase: "title",
    time: 0,
    elapsed: 0,
    score: 0,
    best: 0,
    prevBest: 0,
    combo: 0,
    bestCombo: 0,
    holding: false,
    omega: 0.78,
    player: { angle: -Math.PI / 2, radius: (R_MIN + R_MAX) / 2, radialVel: 0 },
    gates: [],
    motes: [],
    particles: [],
    floaters: [],
    trail: [],
    trauma: 0,
    flash: 0,
    playerFlash: 0,
    hitstop: 0,
    spawned: 0,
    passed: 0,
    nextAngle: 0,
    nextId: 1,
    rng: 48271,
    deathAge: 0,
    crashed: false,
    nearMisses: 0,
    motesTaken: 0,
    newBest: false,
    bestDirty: false,
    shakeOn: true,
    reduced: false,
    cue: null,
  };
}

function rand(sim: Sim): number {
  sim.rng = (sim.rng * 48271) % 2147483647;
  return (sim.rng - 1) / 2147483646;
}

function clamp(n: number, a: number, b: number): number {
  return Math.max(a, Math.min(b, n));
}

function setCue(sim: Sim, cue: Cue) {
  if (!sim.cue || CUE_RANK[cue] >= CUE_RANK[sim.cue]) sim.cue = cue;
}

function bandAround(center: number, width: number): { gapMin: number; gapMax: number } {
  const half = width / 2;
  let gapMin = center - half;
  let gapMax = center + half;
  const lo = R_MIN + 4;
  const hi = R_MAX - 4;
  if (gapMin < lo) {
    gapMax += lo - gapMin;
    gapMin = lo;
  }
  if (gapMax > hi) {
    gapMin -= gapMax - hi;
    gapMax = hi;
  }
  gapMin = Math.max(lo, gapMin);
  gapMax = Math.min(hi, gapMax);
  return { gapMin, gapMax };
}

function gapWidth(elapsed: number, index: number): number {
  if (index === 0) return 160;
  if (index < 3) return 78;
  const shrink = Math.min(64, elapsed * 0.95);
  return Math.max(56, 112 - shrink);
}

function planGap(sim: Sim, index: number, width: number): { gapMin: number; gapMax: number } {
  if (index === 0) return { gapMin: R_MIN + 4, gapMax: R_MAX - 4 };
  if (index === 1) return bandAround(RELEASE_R, width);
  if (index === 2) return bandAround(HOLD_R, width);
  const mid = (R_MIN + R_MAX) / 2;
  const swing = Math.sin(index * 0.95) * 0.62 + (rand(sim) - 0.5) * 0.3;
  const room = (R_MAX - R_MIN) / 2 - width / 2 - 6;
  const center = clamp(mid + swing * room, R_MIN + width / 2 + 4, R_MAX - width / 2 - 4);
  return bandAround(center, width);
}

function worldPos(angle: number, radius: number): TrailPoint {
  return { x: Math.cos(angle) * radius, y: Math.sin(angle) * radius };
}

function burst(sim: Sim, x: number, y: number, n: number, tone: Tone, speed: number) {
  const count = sim.reduced ? Math.ceil(n / 3) : n;
  for (let i = 0; i < count; i++) {
    let p = sim.particles.find((q) => q.life <= 0);
    if (!p) {
      if (sim.particles.length >= 72) return;
      p = { x: 0, y: 0, vx: 0, vy: 0, life: 0, max: 1, size: 2, tone: "bone" };
      sim.particles.push(p);
    }
    const a = (i / count) * Math.PI * 2;
    const sp = speed * (0.45 + (i % 5) * 0.12);
    p.x = x;
    p.y = y;
    p.vx = Math.cos(a) * sp;
    p.vy = Math.sin(a) * sp;
    p.life = p.max = 0.38 + (i % 4) * 0.07;
    p.size = tone === "rust" ? 2.6 : 1.8;
    p.tone = tone;
  }
}

function floater(sim: Sim, x: number, y: number, text: string) {
  let f = sim.floaters.find((q) => q.life <= 0);
  if (!f) {
    if (sim.floaters.length >= 8) f = sim.floaters[0]!;
    else {
      f = { x, y, text, life: 0, max: 0.75 };
      sim.floaters.push(f);
    }
  }
  f.x = x;
  f.y = y;
  f.text = text;
  f.life = f.max = 0.75;
}

function rememberTrail(sim: Sim) {
  const p = worldPos(sim.player.angle, sim.player.radius);
  sim.trail.push(p);
  if (sim.trail.length > 18) sim.trail.shift();
}

function noteScore(sim: Sim) {
  if (sim.score > sim.best) {
    sim.best = sim.score;
    sim.bestDirty = true;
  }
}

function crash(sim: Sim) {
  sim.crashed = true;
  sim.holding = false;
  sim.hitstop = sim.reduced ? 0.04 : 0.09;
  sim.flash = 1;
  sim.trauma = sim.reduced ? 0 : 0.85;
  setCue(sim, "die");
  sim.newBest = sim.score > sim.prevBest && sim.score > 0;
  noteScore(sim);
  const p = worldPos(sim.player.angle, sim.player.radius);
  burst(sim, p.x, p.y, 28, "rust", 150);
  burst(sim, p.x, p.y, 12, "bone", 90);
}

function maybeSpawn(sim: Sim) {
  const horizon = sim.player.angle + 5.4;
  while (sim.nextAngle < horizon && sim.gates.length < 8) {
    const width = gapWidth(sim.elapsed, sim.spawned);
    const gap = planGap(sim, sim.spawned, width);
    const angle = sim.nextAngle;
    sim.gates.push({
      id: sim.nextId++,
      angle,
      gapMin: gap.gapMin,
      gapMax: gap.gapMax,
      resolved: false,
      near: false,
    });
    if (sim.spawned > 0 && (sim.spawned < 3 || rand(sim) < 0.72)) {
      sim.motes.push({
        id: sim.nextId++,
        angle: angle - 0.18,
        radius: (gap.gapMin + gap.gapMax) / 2,
        taken: false,
        missed: false,
      });
    }
    const spacing = Math.max(0.95, 1.42 - Math.min(0.47, sim.elapsed * 0.009));
    sim.nextAngle += spacing;
    sim.spawned += 1;
  }
}

function prune<T extends { angle: number }>(list: T[], minAngle: number) {
  let w = 0;
  for (let i = 0; i < list.length; i++) {
    if (list[i]!.angle >= minAngle) list[w++] = list[i]!;
  }
  list.length = w;
}

function decayPresentation(sim: Sim, dt: number) {
  sim.trauma = Math.max(0, sim.trauma - dt * 1.7);
  sim.flash = Math.max(0, sim.flash - dt * 1.8);
  sim.playerFlash = Math.max(0, sim.playerFlash - dt * 3.2);
  for (const p of sim.particles) {
    if (p.life <= 0) continue;
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
  }
  for (const f of sim.floaters) {
    if (f.life <= 0) continue;
    f.life -= dt;
    f.y += 22 * dt;
  }
}

function attract(sim: Sim, dt: number) {
  sim.player.angle += 0.28 * dt;
  const mid = (R_MIN + R_MAX) / 2;
  const next = mid + Math.sin(sim.time * 0.7) * 48;
  sim.player.radialVel = (next - sim.player.radius) / Math.max(dt, 0.001);
  sim.player.radius = next;
  rememberTrail(sim);
}

export function coach(sim: Sim): string {
  if (sim.phase !== "playing" || sim.crashed) return "";
  if (sim.passed === 0) return "Any line clears the first gate";
  if (sim.passed === 1) return "Release — this slot sits wide";
  if (sim.passed === 2) return "Hold — this slot sits close in";
  return sim.holding ? "Falling inward" : "Drifting outward";
}

export function startRun(sim: Sim) {
  const best = sim.best;
  const shakeOn = sim.shakeOn;
  const reduced = sim.reduced;
  const fresh = createSim();
  Object.assign(sim, fresh);
  sim.best = best;
  sim.prevBest = best;
  sim.shakeOn = shakeOn;
  sim.reduced = reduced;
  sim.phase = "playing";
  sim.player.angle = -Math.PI / 2;
  sim.player.radius = (R_MIN + R_MAX) / 2;
  sim.nextAngle = sim.player.angle + 2.15;
  sim.rng = 48271;
  maybeSpawn(sim);
}

export function pauseRun(sim: Sim) {
  if (sim.phase !== "playing" || sim.crashed) return;
  sim.phase = "paused";
  sim.holding = false;
}

export function resumeRun(sim: Sim) {
  if (sim.phase !== "paused") return;
  sim.phase = "playing";
}

export function toTitle(sim: Sim) {
  const best = sim.best;
  const shakeOn = sim.shakeOn;
  const reduced = sim.reduced;
  const fresh = createSim();
  Object.assign(sim, fresh);
  sim.best = best;
  sim.prevBest = best;
  sim.shakeOn = shakeOn;
  sim.reduced = reduced;
  sim.phase = "title";
}

export function step(sim: Sim, dt: number) {
  sim.cue = null;
  sim.time += dt;
  decayPresentation(sim, dt);

  if (sim.phase === "title") {
    attract(sim, dt);
    return;
  }
  if (sim.phase !== "playing") return;

  if (sim.crashed) {
    sim.deathAge += dt;
    if (sim.hitstop > 0) sim.hitstop -= dt;
    if (sim.deathAge > 0.72) sim.phase = "dead";
    return;
  }

  if (sim.hitstop > 0) {
    sim.hitstop -= dt;
    return;
  }

  sim.elapsed += dt;
  sim.omega = 0.78 + Math.min(1.12, sim.elapsed * 0.018);

  const prevRadius = sim.player.radius;
  const target = sim.holding ? HOLD_R : RELEASE_R;
  const diff = target - sim.player.radius;
  const maxStep = RADIAL_SPEED * dt;
  if (Math.abs(diff) <= maxStep) sim.player.radius = target;
  else sim.player.radius += Math.sign(diff) * maxStep;
  sim.player.radialVel = (sim.player.radius - prevRadius) / dt;

  const prevAngle = sim.player.angle;
  sim.player.angle += sim.omega * dt;
  rememberTrail(sim);
  sim.score += dt * (7 + sim.combo * 0.4);
  noteScore(sim);

  for (const mote of sim.motes) {
    if (mote.taken || mote.missed) continue;
    if (prevAngle < mote.angle && sim.player.angle >= mote.angle) {
      const pos = worldPos(sim.player.angle, sim.player.radius);
      if (Math.abs(sim.player.radius - mote.radius) <= 26) {
        mote.taken = true;
        sim.combo += 1;
        sim.bestCombo = Math.max(sim.bestCombo, sim.combo);
        const pts = 15 * sim.combo;
        sim.score += pts;
        sim.motesTaken += 1;
        sim.hitstop = sim.reduced ? 0 : 0.028;
        sim.playerFlash = 1;
        sim.trauma = Math.min(1, sim.trauma + (sim.reduced ? 0 : 0.12));
        setCue(sim, "collect");
        floater(sim, pos.x, pos.y, `+${pts}`);
        burst(sim, pos.x, pos.y, 10, "bone", 70);
        noteScore(sim);
      } else {
        mote.missed = true;
        sim.combo = 0;
      }
    }
  }

  for (const gate of sim.gates) {
    if (gate.resolved) continue;
    if (prevAngle < gate.angle && sim.player.angle >= gate.angle) {
      gate.resolved = true;
      sim.passed += 1;
      const r = sim.player.radius;
      const outside = r < gate.gapMin - FORGIVE || r > gate.gapMax + FORGIVE;
      if (outside) {
        crash(sim);
        return;
      }
      sim.score += 10;
      noteScore(sim);
      const clearance = Math.min(r - gate.gapMin, gate.gapMax - r);
      if (clearance < 18) {
        gate.near = true;
        sim.nearMisses += 1;
        sim.score += 12;
        noteScore(sim);
        sim.trauma = Math.min(1, sim.trauma + (sim.reduced ? 0 : 0.34));
        setCue(sim, "near");
        const pos = worldPos(sim.player.angle, sim.player.radius);
        floater(sim, pos.x, pos.y + 16, "Close");
        burst(sim, pos.x, pos.y, 8, "bone", 50);
      } else {
        setCue(sim, "gate");
      }
    }
  }

  maybeSpawn(sim);
  prune(sim.gates, sim.player.angle - 0.9);
  prune(sim.motes, sim.player.angle - 0.7);
}

export function selfTest() {
  const live = createSim();
  startRun(live);
  live.gates = [
    {
      id: 99,
      angle: live.player.angle + 0.04,
      gapMin: 200,
      gapMax: 240,
      resolved: false,
      near: false,
    },
  ];
  live.motes = [];
  live.player.radius = 220;
  step(live, 0.1);
  if (live.crashed || !live.gates[0]?.resolved) {
    throw new Error("expected a centered crossing to survive");
  }

  const die = createSim();
  startRun(die);
  die.gates = [
    {
      id: 100,
      angle: die.player.angle + 0.04,
      gapMin: 200,
      gapMax: 240,
      resolved: false,
      near: false,
    },
  ];
  die.motes = [];
  die.player.radius = HOLD_R;
  step(die, 0.1);
  if (!die.crashed) throw new Error("expected an inner crossing to crash");

  const move = createSim();
  startRun(move);
  move.gates = [];
  move.motes = [];
  move.nextAngle = 999;
  const startR = move.player.radius;
  move.holding = true;
  for (let i = 0; i < 20; i++) step(move, 1 / 60);
  if (!(move.player.radius < startR - 40)) {
    throw new Error(`hold did not fall inward (${startR} -> ${move.player.radius})`);
  }
  const fallen = move.player.radius;
  move.holding = false;
  for (let i = 0; i < 30; i++) step(move, 1 / 60);
  if (!(move.player.radius > fallen + 40)) {
    throw new Error(`release did not drift outward (${fallen} -> ${move.player.radius})`);
  }
}
