export class Soundscape {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private music: GainNode | null = null;
  private sfx: GainNode | null = null;
  private drone: { a: OscillatorNode; b: OscillatorNode; gain: GainNode } | null = null;
  muted = false;

  unlock() {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    if (!this.ctx) {
      const ctx = new Ctx({ latencyHint: "interactive" });
      const master = ctx.createGain();
      const music = ctx.createGain();
      const sfx = ctx.createGain();
      master.gain.value = this.muted ? 0 : 0.85;
      music.gain.value = 1;
      sfx.gain.value = 1;
      music.connect(master);
      sfx.connect(master);
      master.connect(ctx.destination);
      this.ctx = ctx;
      this.master = master;
      this.music = music;
      this.sfx = sfx;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  recover() {
    if (this.ctx && this.ctx.state === "suspended") void this.ctx.resume();
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (!this.ctx || !this.master) return;
    this.master.gain.setTargetAtTime(muted ? 0 : 0.85, this.ctx.currentTime, 0.03);
  }

  startDrone() {
    this.unlock();
    if (!this.ctx || !this.music || this.drone) return;
    const a = this.ctx.createOscillator();
    const b = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    a.type = "sine";
    b.type = "triangle";
    a.frequency.value = 78;
    b.frequency.value = 117;
    gain.gain.value = 0.0001;
    a.connect(gain);
    b.connect(gain);
    gain.connect(this.music);
    a.start();
    b.start();
    gain.gain.setTargetAtTime(0.02, this.ctx.currentTime, 0.4);
    this.drone = { a, b, gain };
  }

  stopDrone() {
    if (!this.ctx || !this.drone) return;
    const { a, b, gain } = this.drone;
    gain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.08);
    const stopAt = this.ctx.currentTime + 0.3;
    a.stop(stopAt);
    b.stop(stopAt);
    this.drone = null;
  }

  setTension(t: number) {
    if (!this.ctx || !this.drone) return;
    const k = Math.max(0, Math.min(1, t));
    this.drone.a.frequency.setTargetAtTime(74 + k * 36, this.ctx.currentTime, 0.12);
    this.drone.b.frequency.setTargetAtTime(110 + k * 48, this.ctx.currentTime, 0.12);
  }

  play(cue: "gate" | "near" | "collect" | "die") {
    if (!this.ctx || this.muted) return;
    if (cue === "collect") {
      this.tone(620, 0.09, "sine", 0.06);
      this.tone(930, 0.14, "triangle", 0.04, 0.02);
      return;
    }
    if (cue === "near") {
      this.tone(480, 0.07, "square", 0.025);
      this.tone(720, 0.08, "sine", 0.04, 0.01);
      return;
    }
    if (cue === "gate") {
      this.tone(240, 0.04, "sine", 0.02);
      return;
    }
    this.tone(180, 0.28, "sine", 0.08);
    this.tone(90, 0.4, "triangle", 0.06, 0.02);
    this.noise();
  }

  private tone(
    freq: number,
    dur: number,
    type: OscillatorType,
    gainValue: number,
    delay = 0,
  ) {
    if (!this.ctx || !this.sfx) return;
    const t = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq * (0.97 + Math.random() * 0.06), t);
    gain.gain.setValueAtTime(0.0001, t);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, gainValue), t + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gain);
    gain.connect(this.sfx);
    osc.start(t);
    osc.stop(t + dur + 0.03);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  private noise() {
    if (!this.ctx || !this.sfx) return;
    const length = Math.floor(this.ctx.sampleRate * 0.35);
    const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) {
      const fade = 1 - i / length;
      data[i] = (Math.random() * 2 - 1) * fade * fade;
    }
    const src = this.ctx.createBufferSource();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();
    src.buffer = buffer;
    filter.type = "lowpass";
    filter.frequency.value = 420;
    gain.gain.value = 0.18;
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfx);
    src.start();
    src.onended = () => {
      src.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
  }
}
