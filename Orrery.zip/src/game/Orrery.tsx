import { Pause } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Soundscape } from "@/game/audio";
import { draw, type Camera } from "@/game/draw";
import {
  R_MAX,
  R_MIN,
  coach,
  createSim,
  pauseRun,
  resumeRun,
  startRun,
  step,
  toTitle,
  type Phase,
  type Sim,
} from "@/game/sim";

const STORAGE_KEY = "orrery.v1";

type Settings = { best: number; sound: boolean; shake: boolean };

declare global {
  interface Window {
    __orrery?: {
      phase: () => Phase;
      score: () => number;
      radius: () => number;
      holding: () => boolean;
      setHold: (v: boolean) => void;
      start: () => void;
      passed: () => number;
    };
  }
}

function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { best: 0, sound: true, shake: true };
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return {
      best: typeof parsed.best === "number" ? parsed.best : 0,
      sound: parsed.sound !== false,
      shake: parsed.shake !== false,
    };
  } catch {
    return { best: 0, sound: true, shake: true };
  }
}

function saveSettings(settings: Settings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    /* private mode */
  }
}

function formatScore(n: number) {
  return String(Math.max(0, Math.floor(n)));
}

export function Orrery() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const panelRef = useRef<HTMLElement>(null);
  const scoreRef = useRef<HTMLParagraphElement>(null);
  const bestRef = useRef<HTMLParagraphElement>(null);
  const comboRef = useRef<HTMLParagraphElement>(null);
  const hintRef = useRef<HTMLParagraphElement>(null);
  const retryRef = useRef<HTMLButtonElement>(null);
  const simRef = useRef<Sim>(createSim());
  const audioRef = useRef<Soundscape>(new Soundscape());
  const [phase, setPhase] = useState<Phase>("title");
  const [sound, setSound] = useState(true);
  const [shake, setShake] = useState(true);
  const [card, setCard] = useState({
    score: 0,
    best: 0,
    newBest: false,
    combo: 0,
    motes: 0,
    near: 0,
  });

  useEffect(() => {
    const settings = loadSettings();
    const sim = simRef.current;
    sim.best = settings.best;
    sim.prevBest = settings.best;
    sim.shakeOn = settings.shake;
    sim.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setSound(settings.sound);
    setShake(settings.shake);
    setCard((c) => ({ ...c, best: settings.best }));
    audioRef.current.setMuted(!settings.sound);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let last = performance.now();
    let acc = 0;
    let seen: Phase = sim.phase;

    const sync = () => {
      if (sim.phase !== seen) {
        if (seen === "playing") audioRef.current.stopDrone();
        seen = sim.phase;
        setPhase(sim.phase);
        setCard({
          score: sim.score,
          best: Math.max(sim.best, sim.score),
          newBest: sim.newBest,
          combo: sim.bestCombo,
          motes: sim.motesTaken,
          near: sim.nearMisses,
        });
      }
      if (sim.bestDirty) {
        sim.bestDirty = false;
        saveSettings({ best: sim.best, sound: !audioRef.current.muted, shake: sim.shakeOn });
        setCard((c) => ({ ...c, best: sim.best }));
      }
    };

    const paintHud = () => {
      if (scoreRef.current) scoreRef.current.textContent = formatScore(sim.score);
      if (bestRef.current) bestRef.current.textContent = formatScore(sim.best);
      if (comboRef.current) {
        comboRef.current.textContent = sim.combo > 1 ? `Combo ${sim.combo}` : "";
      }
      if (hintRef.current) hintRef.current.textContent = coach(sim);
    };

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      acc += dt;
      if (acc > 0.25) acc = 0.25;
      while (acc >= 1 / 120) {
        step(sim, 1 / 120);
        if (sim.cue) audioRef.current.play(sim.cue);
        acc -= 1 / 120;
      }
      const norm = (sim.player.radius - R_MIN) / (R_MAX - R_MIN);
      audioRef.current.setTension(1 - norm);
      fitAndDraw(canvas, ctx, sim, panelRef.current);
      paintHud();
      sync();
      raf = requestAnimationFrame(frame);
    };

    const isChrome = (target: EventTarget | null) =>
      target instanceof Element && Boolean(target.closest("[data-chrome]"));

    const onPointerDown = (event: PointerEvent) => {
      if (isChrome(event.target)) return;
      audioRef.current.unlock();
      if (sim.phase === "playing" && !sim.crashed) sim.holding = true;
    };
    const onPointerUp = () => {
      sim.holding = false;
    };
    const onKeyDown = (event: KeyboardEvent) => {
      const onButton = event.target instanceof Element && Boolean(event.target.closest("button"));
      if (event.code === "Space") {
        if (sim.phase === "playing" && !sim.crashed) {
          event.preventDefault();
          audioRef.current.unlock();
          sim.holding = true;
          return;
        }
        if (onButton || event.repeat) return;
        event.preventDefault();
        audioRef.current.unlock();
        if (sim.phase === "paused") {
          resumeRun(sim);
          audioRef.current.startDrone();
        } else if (sim.phase === "title" || sim.phase === "dead") {
          begin();
        }
        return;
      }
      if (event.code === "Escape" && sim.phase === "playing" && !sim.crashed) {
        pauseRun(sim);
        audioRef.current.stopDrone();
        sync();
      }
      if (event.code === "KeyR" && sim.phase === "dead" && !onButton) {
        begin();
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.code === "Space") sim.holding = false;
    };
    const onVis = () => {
      audioRef.current.recover();
      if (document.hidden && sim.phase === "playing" && !sim.crashed) {
        pauseRun(sim);
        audioRef.current.stopDrone();
        sync();
      }
    };

    const begin = () => {
      audioRef.current.unlock();
      audioRef.current.startDrone();
      startRun(sim);
      sync();
    };

    window.__orrery = {
      phase: () => sim.phase,
      score: () => sim.score,
      radius: () => sim.player.radius,
      holding: () => sim.holding,
      setHold: (v: boolean) => {
        sim.holding = v;
      },
      start: begin,
      passed: () => sim.passed,
    };

    window.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointerup", onPointerUp);
    window.addEventListener("pointercancel", onPointerUp);
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    document.addEventListener("visibilitychange", onVis);
    fitAndDraw(canvas, ctx, sim, panelRef.current);
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      document.removeEventListener("visibilitychange", onVis);
      delete window.__orrery;
    };
    // Settings are read once on mount; toggles write through their handlers.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (phase === "dead" || phase === "paused") retryRef.current?.focus();
  }, [phase]);

  const sim = simRef.current;
  const audio = audioRef.current;

  function toggleSound() {
    const next = !sound;
    setSound(next);
    audio.setMuted(!next);
    audio.unlock();
    saveSettings({ best: sim.best, sound: next, shake: sim.shakeOn });
  }

  function toggleShake() {
    const next = !shake;
    setShake(next);
    sim.shakeOn = next;
    saveSettings({ best: sim.best, sound, shake: next });
  }

  function play() {
    audio.unlock();
    audio.startDrone();
    startRun(sim);
    setPhase("playing");
    setCard((c) => ({ ...c, newBest: false, score: 0, motes: 0, near: 0, combo: 0 }));
  }

  function pause() {
    pauseRun(sim);
    audio.stopDrone();
    setPhase(sim.phase);
  }

  function resume() {
    audio.unlock();
    audio.startDrone();
    resumeRun(sim);
    setPhase("playing");
  }

  function title() {
    audio.stopDrone();
    toTitle(sim);
    setPhase("title");
    setCard((c) => ({ ...c, best: sim.best }));
  }

  const showAttractCard = phase === "title" || phase === "dead";

  return (
    <div
      className="relative h-full w-full select-none"
      onContextMenu={(event) => event.preventDefault()}
    >
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full touch-none" aria-hidden />

      {(phase === "playing" || phase === "paused") && (
        <header className="safe-top pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between px-4">
          <div>
            <p className="text-xs font-medium text-faint">Score</p>
            <p ref={scoreRef} className="font-display text-5xl leading-none tabular-nums text-fg">
              0
            </p>
            <p ref={comboRef} className="h-5 text-sm text-muted" />
          </div>
          <div className="pointer-events-auto flex items-center gap-3">
            <p className="text-sm tabular-nums text-muted">
              <span className="text-faint">Best </span>
              <span ref={bestRef}>{formatScore(card.best)}</span>
            </p>
            {phase === "playing" && (
              <button
                type="button"
                data-chrome
                aria-label="Pause"
                onClick={pause}
                className="press grid size-11 place-items-center rounded-full border border-line bg-elevated text-fg"
              >
                <Pause className="size-4" strokeWidth={1.75} aria-hidden />
              </button>
            )}
          </div>
        </header>
      )}

      {phase === "playing" && (
        <p
          ref={hintRef}
          className="safe-bottom pointer-events-none absolute inset-x-0 bottom-0 px-4 text-center text-sm text-muted"
        />
      )}

      {showAttractCard && (
        <div className="pointer-events-none absolute inset-0 flex items-end p-4 md:items-center md:p-8">
          <section
            ref={panelRef}
            data-chrome
            className="overlay-card pointer-events-auto w-full max-w-sm rounded-xl border border-line bg-elevated p-4"
          >
            {phase === "title" ? (
              <>
                <p className="text-xs font-medium text-faint">A one-button orbit</p>
                <h1 className="mt-1 font-display text-5xl leading-none italic text-fg">Orrery</h1>
                <p className="mt-3 text-sm leading-normal text-muted">
                  Ride one ring around a dark star. Thread the bright slot. Catch the motes before
                  the walls close in.
                </p>
                <dl className="mt-4 grid gap-2 text-sm">
                  <div className="flex gap-3">
                    <dt className="w-16 text-faint">Hold</dt>
                    <dd className="text-fg">Fall inward</dd>
                  </div>
                  <div className="flex gap-3">
                    <dt className="w-16 text-faint">Release</dt>
                    <dd className="text-fg">Drift outward</dd>
                  </div>
                  <div className="flex gap-3">
                    <dt className="w-16 text-faint">Aim</dt>
                    <dd className="text-fg">Thread the bright slot</dd>
                  </div>
                </dl>
              </>
            ) : (
              <>
                <p className="text-xs font-medium text-faint">{card.newBest ? "New best" : "Run over"}</p>
                <h2 className="mt-1 font-display text-5xl leading-none tabular-nums text-fg">
                  {formatScore(card.score)}
                </h2>
                <dl className="mt-4 grid grid-cols-3 gap-2 text-sm">
                  <Stat label="Motes" value={String(card.motes)} />
                  <Stat label="Close" value={String(card.near)} />
                  <Stat label="Combo" value={String(card.combo)} />
                </dl>
              </>
            )}

            <div className="mt-5 flex flex-col gap-2">
              <button
                ref={retryRef}
                type="button"
                data-chrome
                onClick={play}
                className="press h-11 rounded-md bg-fg text-sm font-medium text-ink"
              >
                {phase === "title" ? "Play" : "Retry"}
              </button>
              <div className="flex gap-2">
                <button
                  type="button"
                  data-chrome
                  aria-pressed={sound}
                  onClick={toggleSound}
                  className="press h-11 flex-1 rounded-md border border-line text-sm text-fg"
                >
                  {sound ? "Sound on" : "Sound off"}
                </button>
                <button
                  type="button"
                  data-chrome
                  aria-pressed={shake}
                  onClick={toggleShake}
                  className="press h-11 flex-1 rounded-md border border-line text-sm text-fg"
                >
                  {shake ? "Shake on" : "Shake off"}
                </button>
              </div>
              {phase === "dead" && (
                <button
                  type="button"
                  data-chrome
                  onClick={title}
                  className="press h-11 rounded-md text-sm text-muted"
                >
                  Title
                </button>
              )}
            </div>
            <p className="mt-4 hidden text-xs text-faint md:block">Space holds. Esc pauses.</p>
            {phase === "title" && card.best > 0 && (
              <p className="mt-3 text-sm tabular-nums text-muted">Best {formatScore(card.best)}</p>
            )}
          </section>
        </div>
      )}

      {phase === "paused" && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center p-4">
          <section
            data-chrome
            role="dialog"
            aria-modal="true"
            aria-labelledby="pause-title"
            className="overlay-card pointer-events-auto w-full max-w-sm rounded-xl border border-line bg-elevated p-4"
          >
            <h2 id="pause-title" className="font-display text-4xl leading-none text-fg">
              Paused
            </h2>
            <p className="mt-2 text-sm text-muted">Hold falls inward. Release drifts out.</p>
            <div className="mt-5 flex flex-col gap-2">
              <button
                ref={retryRef}
                type="button"
                data-chrome
                onClick={resume}
                className="press h-11 rounded-md bg-fg text-sm font-medium text-ink"
              >
                Resume
              </button>
              <button
                type="button"
                data-chrome
                onClick={title}
                className="press h-11 rounded-md border border-line text-sm text-fg"
              >
                End run
              </button>
            </div>
          </section>
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-faint">{label}</dt>
      <dd className="tabular-nums text-fg">{value}</dd>
    </div>
  );
}

function fitAndDraw(
  canvas: HTMLCanvasElement,
  ctx: CanvasRenderingContext2D,
  sim: Sim,
  panel: HTMLElement | null,
) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  if (w < 2 || h < 2) return;
  const pw = Math.round(w * dpr);
  const ph = Math.round(h * dpr);
  if (canvas.width !== pw || canvas.height !== ph) {
    canvas.width = pw;
    canvas.height = ph;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

  const wide = w >= 768;
  let left = 0;
  let bottom = 0;
  if ((sim.phase === "title" || sim.phase === "dead") && panel) {
    const rect = panel.getBoundingClientRect();
    const host = canvas.getBoundingClientRect();
    if (wide) left = Math.min(rect.width + 48, w * 0.48);
    else bottom = Math.min(Math.max(0, host.bottom - rect.top) + 12, h * 0.58);
  }
  const availW = Math.max(80, w - left);
  const availH = Math.max(80, h - bottom);
  const scale = Math.min(availW, availH) / (2 * (R_MAX + 28));
  const cam: Camera = {
    cx: left + availW / 2,
    cy: availH / 2,
    scale,
    w,
    h,
  };
  draw(ctx, sim, cam);
}
