//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-wo9RORl5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-cqZ2HD8F.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-cqZ2HD8F.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BFj62neS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
