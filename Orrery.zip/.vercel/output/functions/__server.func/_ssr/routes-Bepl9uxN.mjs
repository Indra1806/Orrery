import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Pause } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bepl9uxN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Soundscape = class {
	ctx = null;
	master = null;
	music = null;
	sfx = null;
	drone = null;
	muted = false;
	unlock() {
		const Ctx = window.AudioContext || window.webkitAudioContext;
		if (!Ctx) return;
		if (!this.ctx) {
			const ctx = new Ctx({ latencyHint: "interactive" });
			const master = ctx.createGain();
			const music = ctx.createGain();
			const sfx = ctx.createGain();
			master.gain.value = this.muted ? 0 : .85;
			music.gain.value = 1;
			sfx.gain.value = 1;
			music.connect(master);
			sfx.connect(master);
			master.connect(ctx.destination);
			this.ctx = ctx;
			this.master = master;
			this.music = music;
			this.sfx = sfx;
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	recover() {
		if (this.ctx && this.ctx.state === "suspended") this.ctx.resume();
	}
	setMuted(muted) {
		this.muted = muted;
		if (!this.ctx || !this.master) return;
		this.master.gain.setTargetAtTime(muted ? 0 : .85, this.ctx.currentTime, .03);
	}
	startDrone() {
		this.unlock();
		if (!this.ctx || !this.music || this.drone) return;
		const a = this.ctx.createOscillator();
		const b = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		a.type = "sine";
		b.type = "triangle";
		a.frequency.value = 78;
		b.frequency.value = 117;
		gain.gain.value = 1e-4;
		a.connect(gain);
		b.connect(gain);
		gain.connect(this.music);
		a.start();
		b.start();
		gain.gain.setTargetAtTime(.02, this.ctx.currentTime, .4);
		this.drone = {
			a,
			b,
			gain
		};
	}
	stopDrone() {
		if (!this.ctx || !this.drone) return;
		const { a, b, gain } = this.drone;
		gain.gain.setTargetAtTime(1e-4, this.ctx.currentTime, .08);
		const stopAt = this.ctx.currentTime + .3;
		a.stop(stopAt);
		b.stop(stopAt);
		this.drone = null;
	}
	setTension(t) {
		if (!this.ctx || !this.drone) return;
		const k = Math.max(0, Math.min(1, t));
		this.drone.a.frequency.setTargetAtTime(74 + k * 36, this.ctx.currentTime, .12);
		this.drone.b.frequency.setTargetAtTime(110 + k * 48, this.ctx.currentTime, .12);
	}
	play(cue) {
		if (!this.ctx || this.muted) return;
		if (cue === "collect") {
			this.tone(620, .09, "sine", .06);
			this.tone(930, .14, "triangle", .04, .02);
			return;
		}
		if (cue === "near") {
			this.tone(480, .07, "square", .025);
			this.tone(720, .08, "sine", .04, .01);
			return;
		}
		if (cue === "gate") {
			this.tone(240, .04, "sine", .02);
			return;
		}
		this.tone(180, .28, "sine", .08);
		this.tone(90, .4, "triangle", .06, .02);
		this.noise();
	}
	tone(freq, dur, type, gainValue, delay = 0) {
		if (!this.ctx || !this.sfx) return;
		const t = this.ctx.currentTime + delay;
		const osc = this.ctx.createOscillator();
		const gain = this.ctx.createGain();
		osc.type = type;
		osc.frequency.setValueAtTime(freq * (.97 + Math.random() * .06), t);
		gain.gain.setValueAtTime(1e-4, t);
		gain.gain.exponentialRampToValueAtTime(Math.max(2e-4, gainValue), t + .012);
		gain.gain.exponentialRampToValueAtTime(1e-4, t + dur);
		osc.connect(gain);
		gain.connect(this.sfx);
		osc.start(t);
		osc.stop(t + dur + .03);
		osc.onended = () => {
			osc.disconnect();
			gain.disconnect();
		};
	}
	noise() {
		if (!this.ctx || !this.sfx) return;
		const length = Math.floor(this.ctx.sampleRate * .35);
		const buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
		const data = buffer.getChannelData(0);
		for (let i = 0; i < length; i++) {
			const fade = 1 - i / length;
			data[i] = (Math.random() * 2 - 1) * fade * fade;
		}
		const src = this.ctx.createBufferSource();
		const filter = this.ctx.createBiquadFilter();
		const gain = this.ctx.createGain();
		src.buffer = buffer;
		filter.type = "lowpass";
		filter.frequency.value = 420;
		gain.gain.value = .18;
		src.connect(filter);
		filter.connect(gain);
		gain.connect(this.sfx);
		src.start();
		src.onended = () => {
			src.disconnect();
			filter.disconnect();
			gain.disconnect();
		};
	}
};
var CUE_RANK = {
	gate: 1,
	near: 2,
	collect: 3,
	die: 4
};
function createSim() {
	return {
		phase: "title",
		time: 0,
		elapsed: 0,
		score: 0,
		best: 0,
		prevBest: 0,
		combo: 0,
		bestCombo: 0,
		holding: false,
		omega: .78,
		player: {
			angle: -Math.PI / 2,
			radius: 170,
			radialVel: 0
		},
		gates: [],
		motes: [],
		particles: [],
		floaters: [],
		trail: [],
		trauma: 0,
		flash: 0,
		playerFlash: 0,
		hitstop: 0,
		spawned: 0,
		passed: 0,
		nextAngle: 0,
		nextId: 1,
		rng: 48271,
		deathAge: 0,
		crashed: false,
		nearMisses: 0,
		motesTaken: 0,
		newBest: false,
		bestDirty: false,
		shakeOn: true,
		reduced: false,
		cue: null
	};
}
function rand(sim) {
	sim.rng = sim.rng * 48271 % 2147483647;
	return (sim.rng - 1) / 2147483646;
}
function clamp$1(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
function setCue(sim, cue) {
	if (!sim.cue || CUE_RANK[cue] >= CUE_RANK[sim.cue]) sim.cue = cue;
}
function bandAround(center, width) {
	const half = width / 2;
	let gapMin = center - half;
	let gapMax = center + half;
	const lo = 92;
	const hi = 248;
	if (gapMin < lo) {
		gapMax += lo - gapMin;
		gapMin = lo;
	}
	if (gapMax > hi) {
		gapMin -= gapMax - hi;
		gapMax = hi;
	}
	gapMin = Math.max(lo, gapMin);
	gapMax = Math.min(hi, gapMax);
	return {
		gapMin,
		gapMax
	};
}
function gapWidth(elapsed, index) {
	if (index === 0) return 160;
	if (index < 3) return 78;
	const shrink = Math.min(64, elapsed * .95);
	return Math.max(56, 112 - shrink);
}
function planGap(sim, index, width) {
	if (index === 0) return {
		gapMin: 92,
		gapMax: 248
	};
	if (index === 1) return bandAround(240, width);
	if (index === 2) return bandAround(100, width);
	return bandAround(clamp$1(170 + (Math.sin(index * .95) * .62 + (rand(sim) - .5) * .3) * (82 - width / 2 - 6), 88 + width / 2 + 4, 252 - width / 2 - 4), width);
}
function worldPos(angle, radius) {
	return {
		x: Math.cos(angle) * radius,
		y: Math.sin(angle) * radius
	};
}
function burst(sim, x, y, n, tone, speed) {
	const count = sim.reduced ? Math.ceil(n / 3) : n;
	for (let i = 0; i < count; i++) {
		let p = sim.particles.find((q) => q.life <= 0);
		if (!p) {
			if (sim.particles.length >= 72) return;
			p = {
				x: 0,
				y: 0,
				vx: 0,
				vy: 0,
				life: 0,
				max: 1,
				size: 2,
				tone: "bone"
			};
			sim.particles.push(p);
		}
		const a = i / count * Math.PI * 2;
		const sp = speed * (.45 + i % 5 * .12);
		p.x = x;
		p.y = y;
		p.vx = Math.cos(a) * sp;
		p.vy = Math.sin(a) * sp;
		p.life = p.max = .38 + i % 4 * .07;
		p.size = tone === "rust" ? 2.6 : 1.8;
		p.tone = tone;
	}
}
function floater(sim, x, y, text) {
	let f = sim.floaters.find((q) => q.life <= 0);
	if (!f) {
		if (sim.floaters.length >= 8) f = sim.floaters[0];
		else {
			f = {
				x,
				y,
				text,
				life: 0,
				max: .75
			};
			sim.floaters.push(f);
		}
	}
	f.x = x;
	f.y = y;
	f.text = text;
	f.life = f.max = .75;
}
function rememberTrail(sim) {
	const p = worldPos(sim.player.angle, sim.player.radius);
	sim.trail.push(p);
	if (sim.trail.length > 18) sim.trail.shift();
}
function noteScore(sim) {
	if (sim.score > sim.best) {
		sim.best = sim.score;
		sim.bestDirty = true;
	}
}
function crash(sim) {
	sim.crashed = true;
	sim.holding = false;
	sim.hitstop = sim.reduced ? .04 : .09;
	sim.flash = 1;
	sim.trauma = sim.reduced ? 0 : .85;
	setCue(sim, "die");
	sim.newBest = sim.score > sim.prevBest && sim.score > 0;
	noteScore(sim);
	const p = worldPos(sim.player.angle, sim.player.radius);
	burst(sim, p.x, p.y, 28, "rust", 150);
	burst(sim, p.x, p.y, 12, "bone", 90);
}
function maybeSpawn(sim) {
	const horizon = sim.player.angle + 5.4;
	while (sim.nextAngle < horizon && sim.gates.length < 8) {
		const width = gapWidth(sim.elapsed, sim.spawned);
		const gap = planGap(sim, sim.spawned, width);
		const angle = sim.nextAngle;
		sim.gates.push({
			id: sim.nextId++,
			angle,
			gapMin: gap.gapMin,
			gapMax: gap.gapMax,
			resolved: false,
			near: false
		});
		if (sim.spawned > 0 && (sim.spawned < 3 || rand(sim) < .72)) sim.motes.push({
			id: sim.nextId++,
			angle: angle - .18,
			radius: (gap.gapMin + gap.gapMax) / 2,
			taken: false,
			missed: false
		});
		const spacing = Math.max(.95, 1.42 - Math.min(.47, sim.elapsed * .009));
		sim.nextAngle += spacing;
		sim.spawned += 1;
	}
}
function prune(list, minAngle) {
	let w = 0;
	for (let i = 0; i < list.length; i++) if (list[i].angle >= minAngle) list[w++] = list[i];
	list.length = w;
}
function decayPresentation(sim, dt) {
	sim.trauma = Math.max(0, sim.trauma - dt * 1.7);
	sim.flash = Math.max(0, sim.flash - dt * 1.8);
	sim.playerFlash = Math.max(0, sim.playerFlash - dt * 3.2);
	for (const p of sim.particles) {
		if (p.life <= 0) continue;
		p.life -= dt;
		p.x += p.vx * dt;
		p.y += p.vy * dt;
	}
	for (const f of sim.floaters) {
		if (f.life <= 0) continue;
		f.life -= dt;
		f.y += 22 * dt;
	}
}
function attract(sim, dt) {
	sim.player.angle += .28 * dt;
	const next = 170 + Math.sin(sim.time * .7) * 48;
	sim.player.radialVel = (next - sim.player.radius) / Math.max(dt, .001);
	sim.player.radius = next;
	rememberTrail(sim);
}
function coach(sim) {
	if (sim.phase !== "playing" || sim.crashed) return "";
	if (sim.passed === 0) return "Any line clears the first gate";
	if (sim.passed === 1) return "Release — this slot sits wide";
	if (sim.passed === 2) return "Hold — this slot sits close in";
	return sim.holding ? "Falling inward" : "Drifting outward";
}
function startRun(sim) {
	const best = sim.best;
	const shakeOn = sim.shakeOn;
	const reduced = sim.reduced;
	const fresh = createSim();
	Object.assign(sim, fresh);
	sim.best = best;
	sim.prevBest = best;
	sim.shakeOn = shakeOn;
	sim.reduced = reduced;
	sim.phase = "playing";
	sim.player.angle = -Math.PI / 2;
	sim.player.radius = 170;
	sim.nextAngle = sim.player.angle + 2.15;
	sim.rng = 48271;
	maybeSpawn(sim);
}
function pauseRun(sim) {
	if (sim.phase !== "playing" || sim.crashed) return;
	sim.phase = "paused";
	sim.holding = false;
}
function resumeRun(sim) {
	if (sim.phase !== "paused") return;
	sim.phase = "playing";
}
function toTitle(sim) {
	const best = sim.best;
	const shakeOn = sim.shakeOn;
	const reduced = sim.reduced;
	const fresh = createSim();
	Object.assign(sim, fresh);
	sim.best = best;
	sim.prevBest = best;
	sim.shakeOn = shakeOn;
	sim.reduced = reduced;
	sim.phase = "title";
}
function step(sim, dt) {
	sim.cue = null;
	sim.time += dt;
	decayPresentation(sim, dt);
	if (sim.phase === "title") {
		attract(sim, dt);
		return;
	}
	if (sim.phase !== "playing") return;
	if (sim.crashed) {
		sim.deathAge += dt;
		if (sim.hitstop > 0) sim.hitstop -= dt;
		if (sim.deathAge > .72) sim.phase = "dead";
		return;
	}
	if (sim.hitstop > 0) {
		sim.hitstop -= dt;
		return;
	}
	sim.elapsed += dt;
	sim.omega = .78 + Math.min(1.12, sim.elapsed * .018);
	const prevRadius = sim.player.radius;
	const target = sim.holding ? 100 : 240;
	const diff = target - sim.player.radius;
	const maxStep = 380 * dt;
	if (Math.abs(diff) <= maxStep) sim.player.radius = target;
	else sim.player.radius += Math.sign(diff) * maxStep;
	sim.player.radialVel = (sim.player.radius - prevRadius) / dt;
	const prevAngle = sim.player.angle;
	sim.player.angle += sim.omega * dt;
	rememberTrail(sim);
	sim.score += dt * (7 + sim.combo * .4);
	noteScore(sim);
	for (const mote of sim.motes) {
		if (mote.taken || mote.missed) continue;
		if (prevAngle < mote.angle && sim.player.angle >= mote.angle) {
			const pos = worldPos(sim.player.angle, sim.player.radius);
			if (Math.abs(sim.player.radius - mote.radius) <= 26) {
				mote.taken = true;
				sim.combo += 1;
				sim.bestCombo = Math.max(sim.bestCombo, sim.combo);
				const pts = 15 * sim.combo;
				sim.score += pts;
				sim.motesTaken += 1;
				sim.hitstop = sim.reduced ? 0 : .028;
				sim.playerFlash = 1;
				sim.trauma = Math.min(1, sim.trauma + (sim.reduced ? 0 : .12));
				setCue(sim, "collect");
				floater(sim, pos.x, pos.y, `+${pts}`);
				burst(sim, pos.x, pos.y, 10, "bone", 70);
				noteScore(sim);
			} else {
				mote.missed = true;
				sim.combo = 0;
			}
		}
	}
	for (const gate of sim.gates) {
		if (gate.resolved) continue;
		if (prevAngle < gate.angle && sim.player.angle >= gate.angle) {
			gate.resolved = true;
			sim.passed += 1;
			const r = sim.player.radius;
			if (r < gate.gapMin - 8 || r > gate.gapMax + 8) {
				crash(sim);
				return;
			}
			sim.score += 10;
			noteScore(sim);
			if (Math.min(r - gate.gapMin, gate.gapMax - r) < 18) {
				gate.near = true;
				sim.nearMisses += 1;
				sim.score += 12;
				noteScore(sim);
				sim.trauma = Math.min(1, sim.trauma + (sim.reduced ? 0 : .34));
				setCue(sim, "near");
				const pos = worldPos(sim.player.angle, sim.player.radius);
				floater(sim, pos.x, pos.y + 16, "Close");
				burst(sim, pos.x, pos.y, 8, "bone", 50);
			} else setCue(sim, "gate");
		}
	}
	maybeSpawn(sim);
	prune(sim.gates, sim.player.angle - .9);
	prune(sim.motes, sim.player.angle - .7);
}
var INK = "#0a0a0b";
var BONE = "#f4f4f5";
var SILVER = "#c8ccd4";
var RUST = "#a34a3a";
var DUST = Array.from({ length: 64 }, (_, i) => {
	return {
		a: i * 2.399963 % (Math.PI * 2),
		rr: 30 + i * 53 % 1e3 / 1e3 * 300,
		al: .12 + i % 5 * .05
	};
});
function sx(cam, x) {
	return cam.cx + x * cam.scale;
}
function sy(cam, y) {
	return cam.cy - y * cam.scale;
}
function sector(ctx, cam, r0, r1, a0, a1) {
	const inner = Math.max(1, r0 * cam.scale);
	const outer = Math.max(inner + 1, r1 * cam.scale);
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, outer, -a0, -a1, true);
	ctx.arc(cam.cx, cam.cy, inner, -a1, -a0, false);
	ctx.closePath();
}
function radial(ctx, cam, angle, r0, r1) {
	ctx.beginPath();
	ctx.moveTo(sx(cam, Math.cos(angle) * r0), sy(cam, Math.sin(angle) * r0));
	ctx.lineTo(sx(cam, Math.cos(angle) * r1), sy(cam, Math.sin(angle) * r1));
	ctx.stroke();
}
function draw(ctx, sim, cam) {
	const { w, h } = cam;
	ctx.clearRect(0, 0, w, h);
	ctx.fillStyle = INK;
	ctx.fillRect(0, 0, w, h);
	const wash = ctx.createRadialGradient(cam.cx, cam.cy, 0, cam.cx, cam.cy, Math.max(w, h) * .62);
	wash.addColorStop(0, "#121214");
	wash.addColorStop(1, INK);
	ctx.fillStyle = wash;
	ctx.fillRect(0, 0, w, h);
	const mag = 18 * (sim.shakeOn && !sim.reduced ? sim.trauma * sim.trauma : 0);
	const ox = Math.sin(sim.time * 43) * mag;
	const oy = Math.cos(sim.time * 37) * mag * .65;
	ctx.save();
	ctx.translate(ox, oy);
	for (const d of DUST) {
		ctx.globalAlpha = d.al;
		ctx.fillStyle = SILVER;
		ctx.fillRect(sx(cam, Math.cos(d.a) * d.rr), sy(cam, Math.sin(d.a) * d.rr), 1.4, 1.4);
	}
	ctx.globalAlpha = 1;
	ctx.fillStyle = "rgba(244,244,245,0.035)";
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, 88 * cam.scale, 0, Math.PI * 2);
	ctx.fill();
	ctx.strokeStyle = "rgba(244,244,245,0.09)";
	ctx.lineWidth = 1;
	for (let i = 0; i < 4; i++) {
		const r = 88 + 164 * i / 3;
		ctx.beginPath();
		ctx.arc(cam.cx, cam.cy, r * cam.scale, 0, Math.PI * 2);
		ctx.stroke();
	}
	ctx.strokeStyle = "rgba(244,244,245,0.28)";
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, 254 * cam.scale, 0, Math.PI * 2);
	ctx.stroke();
	ctx.globalAlpha = .45;
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, 264 * cam.scale, 0, Math.PI * 2);
	ctx.stroke();
	ctx.globalAlpha = 1;
	ctx.strokeStyle = "rgba(200,204,212,0.35)";
	for (let i = 0; i < 72; i++) radial(ctx, cam, i / 72 * Math.PI * 2, 252 + (i % 6 === 0 ? 4 : 7), 264);
	const next = sim.gates.find((g) => !g.resolved && g.angle > sim.player.angle - .05);
	for (const gate of sim.gates) {
		const half = .07;
		const a0 = gate.angle - half;
		const a1 = gate.angle + half;
		const imminent = gate === next;
		ctx.fillStyle = imminent ? "rgba(176, 78, 60, 0.92)" : "rgba(163, 74, 58, 0.7)";
		ctx.strokeStyle = imminent ? "rgba(222, 140, 124, 0.95)" : "rgba(176, 92, 76, 0.75)";
		ctx.lineWidth = 1;
		if (gate.gapMin > 90) {
			sector(ctx, cam, 88, gate.gapMin, a0, a1);
			ctx.fill();
			ctx.stroke();
		}
		if (gate.gapMax < 250) {
			sector(ctx, cam, gate.gapMax, 252, a0, a1);
			ctx.fill();
			ctx.stroke();
		}
		ctx.strokeStyle = imminent ? BONE : "rgba(244,244,245,0.7)";
		ctx.lineWidth = imminent ? 3 : 1.75;
		ctx.globalAlpha = gate.near ? 1 : imminent ? .95 : .55;
		radial(ctx, cam, gate.angle, gate.gapMin, gate.gapMax);
		ctx.globalAlpha = 1;
	}
	for (const mote of sim.motes) {
		if (mote.taken) continue;
		const x = sx(cam, Math.cos(mote.angle) * mote.radius);
		const y = sy(cam, Math.sin(mote.angle) * mote.radius);
		const s = Math.max(3.5, 4.2 * cam.scale);
		ctx.globalAlpha = mote.missed ? .25 : .95;
		ctx.fillStyle = BONE;
		ctx.beginPath();
		ctx.moveTo(x, y - s);
		ctx.lineTo(x + s * .72, y);
		ctx.lineTo(x, y + s);
		ctx.lineTo(x - s * .72, y);
		ctx.closePath();
		ctx.fill();
		ctx.globalAlpha = 1;
	}
	const core = ctx.createRadialGradient(cam.cx, cam.cy, 0, cam.cx, cam.cy, 64 * cam.scale);
	core.addColorStop(0, "rgba(244,244,245,0.2)");
	core.addColorStop(1, "rgba(244,244,245,0)");
	ctx.fillStyle = core;
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, 64 * cam.scale, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = BONE;
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, Math.max(8, 16 * cam.scale), 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = INK;
	ctx.beginPath();
	ctx.arc(cam.cx, cam.cy, Math.max(3, 5.5 * cam.scale), 0, Math.PI * 2);
	ctx.fill();
	if (sim.phase !== "dead") {
		ctx.strokeStyle = "rgba(244,244,245,0.16)";
		ctx.lineWidth = 1;
		radial(ctx, cam, sim.player.angle, 88, 252);
		if (sim.phase === "playing" || sim.phase === "title") {
			pip(ctx, cam, sim.player.angle, 100, sim.holding && sim.phase === "playing");
			pip(ctx, cam, sim.player.angle, 240, !sim.holding && sim.phase === "playing");
		}
	}
	ctx.lineWidth = Math.max(1.5, 2 * cam.scale);
	ctx.strokeStyle = BONE;
	ctx.lineCap = "round";
	const trail = sim.trail;
	for (let i = 1; i < trail.length; i++) {
		ctx.globalAlpha = i / trail.length * .5;
		ctx.beginPath();
		ctx.moveTo(sx(cam, trail[i - 1].x), sy(cam, trail[i - 1].y));
		ctx.lineTo(sx(cam, trail[i].x), sy(cam, trail[i].y));
		ctx.stroke();
	}
	ctx.globalAlpha = 1;
	if (!sim.crashed) {
		const px = sx(cam, Math.cos(sim.player.angle) * sim.player.radius);
		const py = sy(cam, Math.sin(sim.player.angle) * sim.player.radius);
		const body = Math.max(5.5, 7 * cam.scale);
		const stretch = sim.reduced ? 1 : 1 + clamp(sim.player.radialVel / 700, -.18, .18);
		ctx.save();
		ctx.translate(px, py);
		ctx.rotate(-sim.player.angle);
		ctx.scale(stretch, 1 / stretch);
		ctx.fillStyle = sim.playerFlash > .4 ? "#ffffff" : BONE;
		ctx.beginPath();
		ctx.arc(0, 0, body, 0, Math.PI * 2);
		ctx.fill();
		ctx.strokeStyle = SILVER;
		ctx.lineWidth = 1;
		ctx.beginPath();
		ctx.arc(0, 0, body + 4, 0, Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	for (const p of sim.particles) {
		if (p.life <= 0) continue;
		ctx.globalAlpha = Math.max(0, p.life / p.max);
		ctx.fillStyle = p.tone === "rust" ? RUST : BONE;
		ctx.beginPath();
		ctx.arc(sx(cam, p.x), sy(cam, p.y), p.size, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
	ctx.font = "600 13px Instrument Sans, sans-serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	for (const f of sim.floaters) {
		if (f.life <= 0) continue;
		ctx.globalAlpha = Math.max(0, f.life / f.max);
		ctx.fillStyle = BONE;
		ctx.fillText(f.text, sx(cam, f.x), sy(cam, f.y));
	}
	ctx.globalAlpha = 1;
	if (sim.phase === "playing" && sim.elapsed < 5.5 && !sim.crashed) {
		ctx.font = "500 11px Instrument Sans, sans-serif";
		ctx.fillStyle = SILVER;
		ctx.globalAlpha = .75;
		const a = sim.player.angle;
		label(ctx, cam, a, 82, "In");
		label(ctx, cam, a, 256, "Out");
		ctx.globalAlpha = 1;
	}
	ctx.restore();
	if (sim.flash > 0) {
		ctx.globalAlpha = Math.min(.45, sim.flash * .35);
		ctx.fillStyle = "#f4f4f5";
		ctx.fillRect(0, 0, w, h);
		ctx.globalAlpha = 1;
	}
}
function pip(ctx, cam, angle, radius, filled) {
	const x = sx(cam, Math.cos(angle) * radius);
	const y = sy(cam, Math.sin(angle) * radius);
	ctx.beginPath();
	ctx.arc(x, y, 3.5, 0, Math.PI * 2);
	ctx.strokeStyle = SILVER;
	ctx.fillStyle = BONE;
	ctx.lineWidth = 1;
	if (filled) ctx.fill();
	else ctx.stroke();
}
function label(ctx, cam, angle, radius, text) {
	ctx.fillText(text, sx(cam, Math.cos(angle) * radius), sy(cam, Math.sin(angle) * radius));
}
function clamp(n, a, b) {
	return Math.max(a, Math.min(b, n));
}
var STORAGE_KEY = "orrery.v1";
function loadSettings() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return {
			best: 0,
			sound: true,
			shake: true
		};
		const parsed = JSON.parse(raw);
		return {
			best: typeof parsed.best === "number" ? parsed.best : 0,
			sound: parsed.sound !== false,
			shake: parsed.shake !== false
		};
	} catch {
		return {
			best: 0,
			sound: true,
			shake: true
		};
	}
}
function saveSettings(settings) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
	} catch {}
}
function formatScore(n) {
	return String(Math.max(0, Math.floor(n)));
}
function Orrery() {
	const canvasRef = (0, import_react.useRef)(null);
	const panelRef = (0, import_react.useRef)(null);
	const scoreRef = (0, import_react.useRef)(null);
	const bestRef = (0, import_react.useRef)(null);
	const comboRef = (0, import_react.useRef)(null);
	const hintRef = (0, import_react.useRef)(null);
	const retryRef = (0, import_react.useRef)(null);
	const simRef = (0, import_react.useRef)(createSim());
	const audioRef = (0, import_react.useRef)(new Soundscape());
	const [phase, setPhase] = (0, import_react.useState)("title");
	const [sound, setSound] = (0, import_react.useState)(true);
	const [shake, setShake] = (0, import_react.useState)(true);
	const [card, setCard] = (0, import_react.useState)({
		score: 0,
		best: 0,
		newBest: false,
		combo: 0,
		motes: 0,
		near: 0
	});
	(0, import_react.useEffect)(() => {
		const settings = loadSettings();
		const sim = simRef.current;
		sim.best = settings.best;
		sim.prevBest = settings.best;
		sim.shakeOn = settings.shake;
		sim.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		setSound(settings.sound);
		setShake(settings.shake);
		setCard((c) => ({
			...c,
			best: settings.best
		}));
		audioRef.current.setMuted(!settings.sound);
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let last = performance.now();
		let acc = 0;
		let seen = sim.phase;
		const sync = () => {
			if (sim.phase !== seen) {
				if (seen === "playing") audioRef.current.stopDrone();
				seen = sim.phase;
				setPhase(sim.phase);
				setCard({
					score: sim.score,
					best: Math.max(sim.best, sim.score),
					newBest: sim.newBest,
					combo: sim.bestCombo,
					motes: sim.motesTaken,
					near: sim.nearMisses
				});
			}
			if (sim.bestDirty) {
				sim.bestDirty = false;
				saveSettings({
					best: sim.best,
					sound: !audioRef.current.muted,
					shake: sim.shakeOn
				});
				setCard((c) => ({
					...c,
					best: sim.best
				}));
			}
		};
		const paintHud = () => {
			if (scoreRef.current) scoreRef.current.textContent = formatScore(sim.score);
			if (bestRef.current) bestRef.current.textContent = formatScore(sim.best);
			if (comboRef.current) comboRef.current.textContent = sim.combo > 1 ? `Combo ${sim.combo}` : "";
			if (hintRef.current) hintRef.current.textContent = coach(sim);
		};
		const frame = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			acc += dt;
			if (acc > .25) acc = .25;
			while (acc >= 1 / 120) {
				step(sim, 1 / 120);
				if (sim.cue) audioRef.current.play(sim.cue);
				acc -= 1 / 120;
			}
			const norm = (sim.player.radius - 88) / 164;
			audioRef.current.setTension(1 - norm);
			fitAndDraw(canvas, ctx, sim, panelRef.current);
			paintHud();
			sync();
			raf = requestAnimationFrame(frame);
		};
		const isChrome = (target) => target instanceof Element && Boolean(target.closest("[data-chrome]"));
		const onPointerDown = (event) => {
			if (isChrome(event.target)) return;
			audioRef.current.unlock();
			if (sim.phase === "playing" && !sim.crashed) sim.holding = true;
		};
		const onPointerUp = () => {
			sim.holding = false;
		};
		const onKeyDown = (event) => {
			const onButton = event.target instanceof Element && Boolean(event.target.closest("button"));
			if (event.code === "Space") {
				if (sim.phase === "playing" && !sim.crashed) {
					event.preventDefault();
					audioRef.current.unlock();
					sim.holding = true;
					return;
				}
				if (onButton || event.repeat) return;
				event.preventDefault();
				audioRef.current.unlock();
				if (sim.phase === "paused") {
					resumeRun(sim);
					audioRef.current.startDrone();
				} else if (sim.phase === "title" || sim.phase === "dead") begin();
				return;
			}
			if (event.code === "Escape" && sim.phase === "playing" && !sim.crashed) {
				pauseRun(sim);
				audioRef.current.stopDrone();
				sync();
			}
			if (event.code === "KeyR" && sim.phase === "dead" && !onButton) begin();
		};
		const onKeyUp = (event) => {
			if (event.code === "Space") sim.holding = false;
		};
		const onVis = () => {
			audioRef.current.recover();
			if (document.hidden && sim.phase === "playing" && !sim.crashed) {
				pauseRun(sim);
				audioRef.current.stopDrone();
				sync();
			}
		};
		const begin = () => {
			audioRef.current.unlock();
			audioRef.current.startDrone();
			startRun(sim);
			sync();
		};
		window.__orrery = {
			phase: () => sim.phase,
			score: () => sim.score,
			radius: () => sim.player.radius,
			holding: () => sim.holding,
			setHold: (v) => {
				sim.holding = v;
			},
			start: begin,
			passed: () => sim.passed
		};
		window.addEventListener("pointerdown", onPointerDown);
		window.addEventListener("pointerup", onPointerUp);
		window.addEventListener("pointercancel", onPointerUp);
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("keyup", onKeyUp);
		document.addEventListener("visibilitychange", onVis);
		fitAndDraw(canvas, ctx, sim, panelRef.current);
		raf = requestAnimationFrame(frame);
		return () => {
			cancelAnimationFrame(raf);
			window.removeEventListener("pointerdown", onPointerDown);
			window.removeEventListener("pointerup", onPointerUp);
			window.removeEventListener("pointercancel", onPointerUp);
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
			document.removeEventListener("visibilitychange", onVis);
			delete window.__orrery;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase === "dead" || phase === "paused") retryRef.current?.focus();
	}, [phase]);
	const sim = simRef.current;
	const audio = audioRef.current;
	function toggleSound() {
		const next = !sound;
		setSound(next);
		audio.setMuted(!next);
		audio.unlock();
		saveSettings({
			best: sim.best,
			sound: next,
			shake: sim.shakeOn
		});
	}
	function toggleShake() {
		const next = !shake;
		setShake(next);
		sim.shakeOn = next;
		saveSettings({
			best: sim.best,
			sound,
			shake: next
		});
	}
	function play() {
		audio.unlock();
		audio.startDrone();
		startRun(sim);
		setPhase("playing");
		setCard((c) => ({
			...c,
			newBest: false,
			score: 0,
			motes: 0,
			near: 0,
			combo: 0
		}));
	}
	function pause() {
		pauseRun(sim);
		audio.stopDrone();
		setPhase(sim.phase);
	}
	function resume() {
		audio.unlock();
		audio.startDrone();
		resumeRun(sim);
		setPhase("playing");
	}
	function title() {
		audio.stopDrone();
		toTitle(sim);
		setPhase("title");
		setCard((c) => ({
			...c,
			best: sim.best
		}));
	}
	const showAttractCard = phase === "title" || phase === "dead";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-full w-full select-none",
		onContextMenu: (event) => event.preventDefault(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				"aria-hidden": true
			}),
			(phase === "playing" || phase === "paused") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "safe-top pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between px-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium text-faint",
						children: "Score"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						ref: scoreRef,
						className: "font-display text-5xl leading-none tabular-nums text-fg",
						children: "0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						ref: comboRef,
						className: "h-5 text-sm text-muted"
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm tabular-nums text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-faint",
							children: "Best "
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							ref: bestRef,
							children: formatScore(card.best)
						})]
					}), phase === "playing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"data-chrome": true,
						"aria-label": "Pause",
						onClick: pause,
						className: "press grid size-11 place-items-center rounded-full border border-line bg-elevated text-fg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {
							className: "size-4",
							strokeWidth: 1.75,
							"aria-hidden": true
						})
					})]
				})]
			}),
			phase === "playing" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				ref: hintRef,
				className: "safe-bottom pointer-events-none absolute inset-x-0 bottom-0 px-4 text-center text-sm text-muted"
			}),
			showAttractCard && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-end p-4 md:items-center md:p-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					ref: panelRef,
					"data-chrome": true,
					className: "overlay-card pointer-events-auto w-full max-w-sm rounded-xl border border-line bg-elevated p-4",
					children: [
						phase === "title" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-faint",
								children: "A one-button orbit"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 font-display text-5xl leading-none italic text-fg",
								children: "Orrery"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-normal text-muted",
								children: "Ride one ring around a dark star. Thread the bright slot. Catch the motes before the walls close in."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 grid gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "w-16 text-faint",
											children: "Hold"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: "Fall inward"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "w-16 text-faint",
											children: "Release"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: "Drift outward"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
											className: "w-16 text-faint",
											children: "Aim"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
											className: "text-fg",
											children: "Thread the bright slot"
										})]
									})
								]
							})
						] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium text-faint",
								children: card.newBest ? "New best" : "Run over"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-5xl leading-none tabular-nums text-fg",
								children: formatScore(card.score)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-4 grid grid-cols-3 gap-2 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Motes",
										value: String(card.motes)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Close",
										value: String(card.near)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										label: "Combo",
										value: String(card.combo)
									})
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									ref: retryRef,
									type: "button",
									"data-chrome": true,
									onClick: play,
									className: "press h-11 rounded-md bg-fg text-sm font-medium text-ink",
									children: phase === "title" ? "Play" : "Retry"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"data-chrome": true,
										"aria-pressed": sound,
										onClick: toggleSound,
										className: "press h-11 flex-1 rounded-md border border-line text-sm text-fg",
										children: sound ? "Sound on" : "Sound off"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"data-chrome": true,
										"aria-pressed": shake,
										onClick: toggleShake,
										className: "press h-11 flex-1 rounded-md border border-line text-sm text-fg",
										children: shake ? "Shake on" : "Shake off"
									})]
								}),
								phase === "dead" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"data-chrome": true,
									onClick: title,
									className: "press h-11 rounded-md text-sm text-muted",
									children: "Title"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 hidden text-xs text-faint md:block",
							children: "Space holds. Esc pauses."
						}),
						phase === "title" && card.best > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm tabular-nums text-muted",
							children: ["Best ", formatScore(card.best)]
						})
					]
				})
			}),
			phase === "paused" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-center justify-center p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					"data-chrome": true,
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": "pause-title",
					className: "overlay-card pointer-events-auto w-full max-w-sm rounded-xl border border-line bg-elevated p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "pause-title",
							className: "font-display text-4xl leading-none text-fg",
							children: "Paused"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "Hold falls inward. Release drifts out."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								ref: retryRef,
								type: "button",
								"data-chrome": true,
								onClick: resume,
								className: "press h-11 rounded-md bg-fg text-sm font-medium text-ink",
								children: "Resume"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"data-chrome": true,
								onClick: title,
								className: "press h-11 rounded-md border border-line text-sm text-fg",
								children: "End run"
							})]
						})
					]
				})
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
		className: "text-xs text-faint",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "tabular-nums text-fg",
		children: value
	})] });
}
function fitAndDraw(canvas, ctx, sim, panel) {
	const dpr = Math.min(window.devicePixelRatio || 1, 2);
	const w = canvas.clientWidth;
	const h = canvas.clientHeight;
	if (w < 2 || h < 2) return;
	const pw = Math.round(w * dpr);
	const ph = Math.round(h * dpr);
	if (canvas.width !== pw || canvas.height !== ph) {
		canvas.width = pw;
		canvas.height = ph;
	}
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	const wide = w >= 768;
	let left = 0;
	let bottom = 0;
	if ((sim.phase === "title" || sim.phase === "dead") && panel) {
		const rect = panel.getBoundingClientRect();
		const host = canvas.getBoundingClientRect();
		if (wide) left = Math.min(rect.width + 48, w * .48);
		else bottom = Math.min(Math.max(0, host.bottom - rect.top) + 12, h * .58);
	}
	const availW = Math.max(80, w - left);
	const availH = Math.max(80, h - bottom);
	const scale = Math.min(availW, availH) / 560;
	draw(ctx, sim, {
		cx: left + availW / 2,
		cy: availH / 2,
		scale,
		w,
		h
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "h-dvh w-full overflow-hidden bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orrery, {})
	});
}
//#endregion
export { Home as component };
