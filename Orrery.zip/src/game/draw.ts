import { HOLD_R, R_MAX, R_MIN, RELEASE_R, type Sim } from "@/game/sim";

export type Camera = {
  cx: number;
  cy: number;
  scale: number;
  w: number;
  h: number;
};

const INK = "#0a0a0b";
const BONE = "#f4f4f5";
const SILVER = "#c8ccd4";
const RUST = "#a34a3a";

const DUST = Array.from({ length: 64 }, (_, i) => {
  const a = (i * 2.399963) % (Math.PI * 2);
  const rr = 30 + ((i * 53) % 1000) / 1000 * (R_MAX + 48);
  return { a, rr, al: 0.12 + (i % 5) * 0.05 };
});

function sx(cam: Camera, x: number) {
  return cam.cx + x * cam.scale;
}
function sy(cam: Camera, y: number) {
  return cam.cy - y * cam.scale;
}

function sector(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  r0: number,
  r1: number,
  a0: number,
  a1: number,
) {
  const inner = Math.max(1, r0 * cam.scale);
  const outer = Math.max(inner + 1, r1 * cam.scale);
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, outer, -a0, -a1, true);
  ctx.arc(cam.cx, cam.cy, inner, -a1, -a0, false);
  ctx.closePath();
}

function radial(
  ctx: CanvasRenderingContext2D,
  cam: Camera,
  angle: number,
  r0: number,
  r1: number,
) {
  ctx.beginPath();
  ctx.moveTo(sx(cam, Math.cos(angle) * r0), sy(cam, Math.sin(angle) * r0));
  ctx.lineTo(sx(cam, Math.cos(angle) * r1), sy(cam, Math.sin(angle) * r1));
  ctx.stroke();
}

export function draw(ctx: CanvasRenderingContext2D, sim: Sim, cam: Camera) {
  const { w, h } = cam;
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = INK;
  ctx.fillRect(0, 0, w, h);

  const wash = ctx.createRadialGradient(cam.cx, cam.cy, 0, cam.cx, cam.cy, Math.max(w, h) * 0.62);
  wash.addColorStop(0, "#121214");
  wash.addColorStop(1, INK);
  ctx.fillStyle = wash;
  ctx.fillRect(0, 0, w, h);

  const shake =
    sim.shakeOn && !sim.reduced ? sim.trauma * sim.trauma : 0;
  const mag = 18 * shake;
  const ox = Math.sin(sim.time * 43) * mag;
  const oy = Math.cos(sim.time * 37) * mag * 0.65;

  ctx.save();
  ctx.translate(ox, oy);

  for (const d of DUST) {
    ctx.globalAlpha = d.al;
    ctx.fillStyle = SILVER;
    ctx.fillRect(sx(cam, Math.cos(d.a) * d.rr), sy(cam, Math.sin(d.a) * d.rr), 1.4, 1.4);
  }
  ctx.globalAlpha = 1;

  ctx.fillStyle = "rgba(244,244,245,0.035)";
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, R_MIN * cam.scale, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "rgba(244,244,245,0.09)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    const r = R_MIN + ((R_MAX - R_MIN) * i) / 3;
    ctx.beginPath();
    ctx.arc(cam.cx, cam.cy, r * cam.scale, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.strokeStyle = "rgba(244,244,245,0.28)";
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, (R_MAX + 2) * cam.scale, 0, Math.PI * 2);
  ctx.stroke();
  ctx.globalAlpha = 0.45;
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, (R_MAX + 12) * cam.scale, 0, Math.PI * 2);
  ctx.stroke();
  ctx.globalAlpha = 1;

  ctx.strokeStyle = "rgba(200,204,212,0.35)";
  for (let i = 0; i < 72; i++) {
    const a = (i / 72) * Math.PI * 2;
    const long = i % 6 === 0;
    radial(ctx, cam, a, R_MAX + (long ? 4 : 7), R_MAX + 12);
  }

  const next = sim.gates.find((g) => !g.resolved && g.angle > sim.player.angle - 0.05);
  for (const gate of sim.gates) {
    const half = 0.07;
    const a0 = gate.angle - half;
    const a1 = gate.angle + half;
    const imminent = gate === next;
    ctx.fillStyle = imminent ? "rgba(176, 78, 60, 0.92)" : "rgba(163, 74, 58, 0.7)";
    ctx.strokeStyle = imminent ? "rgba(222, 140, 124, 0.95)" : "rgba(176, 92, 76, 0.75)";
    ctx.lineWidth = 1;
    if (gate.gapMin > R_MIN + 2) {
      sector(ctx, cam, R_MIN, gate.gapMin, a0, a1);
      ctx.fill();
      ctx.stroke();
    }
    if (gate.gapMax < R_MAX - 2) {
      sector(ctx, cam, gate.gapMax, R_MAX, a0, a1);
      ctx.fill();
      ctx.stroke();
    }
    ctx.strokeStyle = imminent ? BONE : "rgba(244,244,245,0.7)";
    ctx.lineWidth = imminent ? 3 : 1.75;
    ctx.globalAlpha = gate.near ? 1 : imminent ? 0.95 : 0.55;
    radial(ctx, cam, gate.angle, gate.gapMin, gate.gapMax);
    ctx.globalAlpha = 1;
  }

  for (const mote of sim.motes) {
    if (mote.taken) continue;
    const x = sx(cam, Math.cos(mote.angle) * mote.radius);
    const y = sy(cam, Math.sin(mote.angle) * mote.radius);
    const s = Math.max(3.5, 4.2 * cam.scale);
    ctx.globalAlpha = mote.missed ? 0.25 : 0.95;
    ctx.fillStyle = BONE;
    ctx.beginPath();
    ctx.moveTo(x, y - s);
    ctx.lineTo(x + s * 0.72, y);
    ctx.lineTo(x, y + s);
    ctx.lineTo(x - s * 0.72, y);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  const core = ctx.createRadialGradient(cam.cx, cam.cy, 0, cam.cx, cam.cy, 64 * cam.scale);
  core.addColorStop(0, "rgba(244,244,245,0.2)");
  core.addColorStop(1, "rgba(244,244,245,0)");
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, 64 * cam.scale, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = BONE;
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, Math.max(8, 16 * cam.scale), 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = INK;
  ctx.beginPath();
  ctx.arc(cam.cx, cam.cy, Math.max(3, 5.5 * cam.scale), 0, Math.PI * 2);
  ctx.fill();

  if (sim.phase !== "dead") {
    ctx.strokeStyle = "rgba(244,244,245,0.16)";
    ctx.lineWidth = 1;
    radial(ctx, cam, sim.player.angle, R_MIN, R_MAX);
    const showGuide = sim.phase === "playing" || sim.phase === "title";
    if (showGuide) {
      pip(ctx, cam, sim.player.angle, HOLD_R, sim.holding && sim.phase === "playing");
      pip(ctx, cam, sim.player.angle, RELEASE_R, !sim.holding && sim.phase === "playing");
    }
  }

  ctx.lineWidth = Math.max(1.5, 2 * cam.scale);
  ctx.strokeStyle = BONE;
  ctx.lineCap = "round";
  const trail = sim.trail;
  for (let i = 1; i < trail.length; i++) {
    ctx.globalAlpha = (i / trail.length) * 0.5;
    ctx.beginPath();
    ctx.moveTo(sx(cam, trail[i - 1]!.x), sy(cam, trail[i - 1]!.y));
    ctx.lineTo(sx(cam, trail[i]!.x), sy(cam, trail[i]!.y));
    ctx.stroke();
  }
  ctx.globalAlpha = 1;

  if (!sim.crashed) {
    const px = sx(cam, Math.cos(sim.player.angle) * sim.player.radius);
    const py = sy(cam, Math.sin(sim.player.angle) * sim.player.radius);
    const body = Math.max(5.5, 7 * cam.scale);
    const stretch = sim.reduced ? 1 : 1 + clamp(sim.player.radialVel / 700, -0.18, 0.18);
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(-sim.player.angle);
    ctx.scale(stretch, 1 / stretch);
    ctx.fillStyle = sim.playerFlash > 0.4 ? "#ffffff" : BONE;
    ctx.beginPath();
    ctx.arc(0, 0, body, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = SILVER;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 0, body + 4, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  for (const p of sim.particles) {
    if (p.life <= 0) continue;
    ctx.globalAlpha = Math.max(0, p.life / p.max);
    ctx.fillStyle = p.tone === "rust" ? RUST : BONE;
    ctx.beginPath();
    ctx.arc(sx(cam, p.x), sy(cam, p.y), p.size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;

  ctx.font = "600 13px Instrument Sans, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  for (const f of sim.floaters) {
    if (f.life <= 0) continue;
    ctx.globalAlpha = Math.max(0, f.life / f.max);
    ctx.fillStyle = BONE;
    ctx.fillText(f.text, sx(cam, f.x), sy(cam, f.y));
  }
  ctx.globalAlpha = 1;

  if (sim.phase === "playing" && sim.elapsed < 5.5 && !sim.crashed) {
    ctx.font = "500 11px Instrument Sans, sans-serif";
    ctx.fillStyle = SILVER;
    ctx.globalAlpha = 0.75;
    const a = sim.player.angle;
    label(ctx, cam, a, HOLD_R - 18, "In");
    label(ctx, cam, a, RELEASE_R + 16, "Out");
    ctx.globalAlpha = 1;
  }

  ctx.restore();

  if (sim.flash > 0) {
    ctx.globalAlpha = Math.min(0.45, sim.flash * 0.35);
    ctx.fillStyle = "#f4f4f5";
    ctx.fillRect(0, 0, w, h);
    ctx.globalAlpha = 1;
  }
}

function pip(ctx: CanvasRenderingContext2D, cam: Camera, angle: number, radius: number, filled: boolean) {
  const x = sx(cam, Math.cos(angle) * radius);
  const y = sy(cam, Math.sin(angle) * radius);
  ctx.beginPath();
  ctx.arc(x, y, 3.5, 0, Math.PI * 2);
  ctx.strokeStyle = SILVER;
  ctx.fillStyle = BONE;
  ctx.lineWidth = 1;
  if (filled) ctx.fill();
  else ctx.stroke();
}

function label(ctx: CanvasRenderingContext2D, cam: Camera, angle: number, radius: number, text: string) {
  ctx.fillText(text, sx(cam, Math.cos(angle) * radius), sy(cam, Math.sin(angle) * radius));
}

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}
